package com.cognizant.Main.controller;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cognizant.Main.dto.CategoryDTO;
import com.cognizant.Main.dto.OrderDTO;
import com.cognizant.Main.dto.ProductDTO;
import com.cognizant.Main.entities.Category;
import com.cognizant.Main.entities.Product;
import com.cognizant.Main.repository.ProductRepository;
import com.cognizant.Main.service.admin.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {


	@Autowired
	private AdminService adminService;
//	@Autowired
//	private ProductRepository productRepository;
//	
	@PostMapping("/category")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<?> createCategory(@RequestBody CategoryDTO categoryDTO) {
	    if (categoryDTO.getName() == null || categoryDTO.getName().isEmpty() || categoryDTO.getDescription() == null || categoryDTO.getDescription().isEmpty()) {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.singletonMap("message", "Enter Proper Input"));
	    }

	    Category createdCategory = adminService.createdCategory(categoryDTO);
	    return ResponseEntity.status(HttpStatus.CREATED).body(createdCategory);
	}


	
	
	@GetMapping("/categories")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<List<CategoryDTO>> getAllCategories()
	{
		List<CategoryDTO> allCategories = adminService.getAllCategories();
		return ResponseEntity.ok(allCategories);
	}
	
	
    @GetMapping("/products")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<List<ProductDTO>> getAllProducts()
	{
		List<ProductDTO> productDtoList = adminService.getAllProducts();
		return ResponseEntity.ok(productDtoList);
	}
    
    @PostMapping("/product/{categoryId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> postProduct(@PathVariable Long categoryId, 
                                         @RequestParam("image") MultipartFile image,
                                         @RequestParam("name") String name,
                                         @RequestParam("description") String description,
                                         @RequestParam("price") Integer price) throws IOException {
        if (name.isEmpty() || description.isEmpty() || price == null || image.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Enter Proper Input Information");
        }

        ProductDTO productDTO = new ProductDTO();
        productDTO.setName(name);
        productDTO.setDescription(description);
        productDTO.setPrice(price);
        productDTO.setCategoryId(categoryId);
        productDTO.setImages(image);

        Product postedProduct = adminService.postProduct(categoryId, productDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(postedProduct);
    }
    
    
    @DeleteMapping("/product/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id)
    {
    	adminService.deleteproduct(id);
    	return ResponseEntity.noContent().build();
    }
    
    
    @GetMapping("/product/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getProductById(@PathVariable Long id)
    {
    	ProductDTO productDTO = adminService.getProductById(id);
    	if(productDTO==null)
    	{
    		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Please Enter Valid Product Id");
    	}
    	return ResponseEntity.ok(productDTO);
    }
        
    @PutMapping("/{categoryId}/product/{productId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> updateProduct(
            @PathVariable Long categoryId,
            @PathVariable Long productId,
            @ModelAttribute ProductDTO productDTO,
            @RequestHeader HttpHeaders headers) {
        // Logging incoming headers
        System.out.println("Authorization Header: " + headers.get("Authorization"));

        ProductDTO updateProduct = adminService.UpdateProduct(categoryId, productId, productDTO);
        if (updateProduct == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Product is not updated properly");
        }
        return ResponseEntity.ok(updateProduct);
    }

    @GetMapping("/orders")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getAllOrders()
    {
    	List<OrderDTO> orderDTOList = adminService.getAllOrders();
    	if(orderDTOList==null)
    	{
    		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No orders Placed!!");
    	}
    	return ResponseEntity.ok(orderDTOList);
    }
}
