package com.cognizant.Main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.Main.dto.ProductDTO;
import com.cognizant.Main.service.customer.CustomerService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class productController {
    @Autowired
	private CustomerService customerService;
	@GetMapping("/products")
	public ResponseEntity<List<ProductDTO>> getAllProducts() {
		List<ProductDTO> productDtoList = customerService.getAllProducts();
		return ResponseEntity.ok(productDtoList);
	}
	
	@GetMapping("/product/search/{title}")
	public ResponseEntity<?> searchProductByTitle(@PathVariable String title) {
		List<ProductDTO> productDtoList = customerService.searchProductByTitle(title);
		if(productDtoList==null)
		{
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Product is not present");
		}
		return ResponseEntity.ok(productDtoList);
	}

}
