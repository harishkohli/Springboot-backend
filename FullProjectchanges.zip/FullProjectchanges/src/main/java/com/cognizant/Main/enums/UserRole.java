package com.cognizant.Main.enums;

public enum UserRole {

	ADMIN, USER
	
}
