package com.productvity.mtool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyProductivityMonitoringSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
