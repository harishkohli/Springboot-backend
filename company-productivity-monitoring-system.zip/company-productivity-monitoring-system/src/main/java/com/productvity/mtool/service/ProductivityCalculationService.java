package com.productvity.mtool.service;

import com.productvity.mtool.Repository.*;
import com.productvity.mtool.dto.CeoReportDto;
import com.productvity.mtool.dto.DeveloperReportDto;
import com.productvity.mtool.entity.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;


@Service
public class ProductivityCalculationService {

    private static final Logger logger = LoggerFactory.getLogger(ProductivityCalculationService.class);

    @Autowired
    private DeveloperRepository developerRepository;
    @Autowired
    private GithubActivityRepository githubActivityRepository;
    @Autowired
    private JiraActivityRepository jiraActivityRepository;
    @Autowired
    private ProductivityRepository dailyProductivityRepository;
    @Autowired
    private CeoReportRepository ceoReportRepository;
    @Autowired
    private TeamRepository teamRepository;

    @Transactional
    public void calculateAndSaveDailyProductivity(LocalDate date) {
        logger.info("Calculating daily productivity for date: {}", date);
        dailyProductivityRepository.deleteAllByDate(date);

        List<Developer> developers = developerRepository.findAll();

        for (Developer developer : developers) {
            List<GithubActivity> developerGithubActivities = githubActivityRepository.findByDeveloperId(developer.getId());

            int commits = (int) developerGithubActivities.stream()
                    .filter(activity -> activity.getCommitDate().withZoneSameInstant(ZoneId.systemDefault()).toLocalDate().equals(date))
                    .count();

            Set<String> uniquePrs = developerGithubActivities.stream()
                    .filter(activity -> activity.getCommitDate().withZoneSameInstant(ZoneId.systemDefault()).toLocalDate().equals(date)
                            && activity.getPrId() != null && !activity.getPrId().isEmpty())
                    .map(GithubActivity::getPrId)
                    .collect(Collectors.toSet());
            int pullRequests = uniquePrs.size();

            List<JiraActivity> developerJiraActivities = jiraActivityRepository.findByDeveloperId(developer.getId());

            List<JiraActivity> completedTasksToday = developerJiraActivities.stream()
                    .filter(activity -> activity.getCompletedDate() != null
                            && activity.getCompletedDate().withZoneSameInstant(ZoneId.systemDefault()).toLocalDate().equals(date)
                            && "Done".equalsIgnoreCase(activity.getStatus()))
                    .collect(Collectors.toList());

            int jiraTasksCompleted = completedTasksToday.size();
            int bugsFixed = (int) completedTasksToday.stream()
                    .filter(activity -> activity.getIssueSummary().toLowerCase().contains("bug"))
                    .count();
            int storyPointsCompleted = completedTasksToday.stream()
                    .mapToInt(JiraActivity::getStoryPoints)
                    .sum();
            
            int deploymentCount = (int) developerGithubActivities.stream()
                .filter(activity -> activity.getCommitDate().withZoneSameInstant(ZoneId.systemDefault()).toLocalDate().equals(date))
                .filter(activity -> activity.getCommitMessage().toLowerCase().contains("deploy") || activity.getCommitMessage().toLowerCase().contains("release"))
                .count();

            // Simulate DORA metrics for demonstration
            double cycleTime = pullRequests > 0 ? ThreadLocalRandom.current().nextDouble(8, 48) : 0;
            double changeFailureRate = deploymentCount > 0 && bugsFixed > 0 ? ThreadLocalRandom.current().nextDouble(5, 15) : 0;

            DailyProductivity dailyProductivity = new DailyProductivity();
            dailyProductivity.setDeveloper(developer);
            dailyProductivity.setDate(date);
            dailyProductivity.setCommits(commits);
            dailyProductivity.setPullRequests(pullRequests);
            dailyProductivity.setIssuesClosed(jiraTasksCompleted);
            dailyProductivity.setJiraTasksCompleted(jiraTasksCompleted);
            dailyProductivity.setBugsFixed(bugsFixed);
            dailyProductivity.setStoryPointsCompleted(storyPointsCompleted);
            dailyProductivity.setCodeReviews(0);
            dailyProductivity.setDeploymentCount(deploymentCount);
            
            // **FIX**: Save the calculated DORA metrics to the database.
            dailyProductivity.setCycleTime(cycleTime);
            dailyProductivity.setChangeFailureRate(changeFailureRate);

            dailyProductivityRepository.save(dailyProductivity);
            logger.info("Saved new daily productivity for developer {}: Commits {}, Story Points {}", developer.getName(), commits, storyPointsCompleted);
        }
    }

    @Transactional
    public void generateCeoReports(LocalDate date) {
        logger.info("Generating CEO reports for date: {}", date);
        ceoReportRepository.deleteAllByReportDate(date);

        List<Team> teams = teamRepository.findAll();

        for (Team team : teams) {
            List<Developer> developersInTeam = developerRepository.findByTeam(team);
            if (developersInTeam.isEmpty()) continue;

            List<DailyProductivity> teamProductivity = dailyProductivityRepository.findByDeveloperTeamIdAndDate(team.getId(), date);

            int totalCommits = teamProductivity.stream().mapToInt(DailyProductivity::getCommits).sum();
            int totalTasksCompleted = teamProductivity.stream().mapToInt(DailyProductivity::getJiraTasksCompleted).sum();
            int totalDeployments = teamProductivity.stream().mapToInt(DailyProductivity::getDeploymentCount).sum();
            int totalStoryPointsCompleted = teamProductivity.stream().mapToInt(DailyProductivity::getStoryPointsCompleted).sum();
            
            double totalProductivityScore = 0;
            for (DailyProductivity dp : teamProductivity) {
                 totalProductivityScore += (dp.getCommits() * 0.5) +
                            (dp.getJiraTasksCompleted() * 1.0) +
                            (dp.getBugsFixed() * 1.5) +
                            (dp.getStoryPointsCompleted() * 2.0) +
                            (dp.getDeploymentCount() * 2.0);
            }

            double averageProductivityScore = !teamProductivity.isEmpty() ? totalProductivityScore / teamProductivity.size() : 0.0;

            CeoReport ceoReport = new CeoReport();
            ceoReport.setReportDate(date);
            ceoReport.setTeam(team);
            ceoReport.setTotalCommits(totalCommits);
            ceoReport.setTotalTasksCompleted(totalTasksCompleted);
            ceoReport.setTotalDeployments(totalDeployments);
            ceoReport.setTotalStoryPointsCompleted(totalStoryPointsCompleted);
            ceoReport.setAverageProductivityScore(averageProductivityScore);
            
            ceoReportRepository.save(ceoReport);
            logger.info("Generated new CEO report for team {}: SPs {}, Avg Score {}", team.getName(), totalStoryPointsCompleted, averageProductivityScore);
        }
    }

    public List<CeoReportDto> getCeoReportDtos(LocalDate date) {
        List<Team> teams = teamRepository.findAll();
        List<CeoReportDto> reportDtos = new ArrayList<>();

        for (Team team : teams) {
            List<Developer> developersInTeam = developerRepository.findByTeam(team);
            if (developersInTeam.isEmpty()) continue;

            List<DailyProductivity> teamProductivityToday = dailyProductivityRepository.findByDeveloperTeamIdAndDate(team.getId(), date);

            CeoReportDto teamReportDto = new CeoReportDto();
            teamReportDto.setTeamId(team.getId());
            teamReportDto.setTeamName(team.getName());

            List<DeveloperReportDto> developerReports = new ArrayList<>();
            double totalProductivityScoreSum = 0;

            for (Developer developer : developersInTeam) {
                DailyProductivity dp = teamProductivityToday.stream()
                        .filter(p -> p.getDeveloper().getId().equals(developer.getId()))
                        .findFirst().orElse(null);

                DeveloperReportDto devReport = new DeveloperReportDto();
                devReport.setDeveloperId(developer.getId());
                devReport.setDeveloperName(developer.getName());

                if (dp != null) {
                    double developerProductivity = (dp.getCommits() * 0.5) +
                            (dp.getJiraTasksCompleted() * 1.0) +
                            (dp.getBugsFixed() * 1.5) +
                            (dp.getStoryPointsCompleted() * 2.0) +
                            (dp.getDeploymentCount() * 2.0);
                    totalProductivityScoreSum += developerProductivity;

                    devReport.setTotalCommits(dp.getCommits());
                    devReport.setTotalTasksCompleted(dp.getJiraTasksCompleted());
                    devReport.setProductivityScore(developerProductivity);
                    devReport.setDeploymentFrequency(dp.getDeploymentCount() * 7.0);
                  
                    // **FIX**: Transfer DORA metrics from daily data to the final report DTO.
                    devReport.setLeadTimeForChanges(dp.getCycleTime());
                    devReport.setChangeFailureRate(dp.getChangeFailureRate());
                }
                developerReports.add(devReport);
            }
            
            teamReportDto.setDeveloperReports(developerReports);
            teamReportDto.setTotalCommits(developerReports.stream().mapToInt(DeveloperReportDto::getTotalCommits).sum());
            teamReportDto.setTotalTasksCompleted(developerReports.stream().mapToInt(DeveloperReportDto::getTotalTasksCompleted).sum());
            teamReportDto.setAverageProductivityScore(developersInTeam.isEmpty() ? 0 : totalProductivityScoreSum / developersInTeam.size());
            
            teamReportDto.setDeploymentFrequency(developerReports.stream().mapToDouble(DeveloperReportDto::getDeploymentFrequency).sum());
            teamReportDto.setLeadTimeForChanges(developerReports.stream().mapToDouble(DeveloperReportDto::getLeadTimeForChanges).average().orElse(0));
            teamReportDto.setChangeFailureRate(developerReports.stream().mapToDouble(DeveloperReportDto::getChangeFailureRate).average().orElse(0));

            reportDtos.add(teamReportDto);
        }
        return reportDtos;
    }
}