package com.productvity.mtool.dto;

import com.productvity.mtool.entity.Developer;

public class JwtResponse {
    private String token;
    private Developer user;

    public JwtResponse(String token, Developer user) {
        this.token = token;
        this.user = user;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Developer getUser() {
        return user;
    }

    public void setUser(Developer user) {
        this.user = user;
    }
}