package com.productvity.mtool.dto;

import java.util.List;

public class CeoReportDto {

    private Long teamId;
    private String teamName;
    private int totalCommits;
    private int totalTasksCompleted;
    private int totalStoryPointsCompleted;
    private double averageProductivityScore;
    private double deploymentFrequency;
    private double leadTimeForChanges;
    private double changeFailureRate;
    private List<DeveloperReportDto> developerReports;

    // Getters and Setters
    public Long getTeamId() { return teamId; }
    public void setTeamId(Long teamId) { this.teamId = teamId; }
    public String getTeamName() { return teamName; }
    public void setTeamName(String teamName) { this.teamName = teamName; }
    public int getTotalCommits() { return totalCommits; }
    public void setTotalCommits(int totalCommits) { this.totalCommits = totalCommits; }
    public int getTotalTasksCompleted() { return totalTasksCompleted; }
    public void setTotalTasksCompleted(int totalTasksCompleted) { this.totalTasksCompleted = totalTasksCompleted; }
    public int getTotalStoryPointsCompleted() { return totalStoryPointsCompleted; }
    public void setTotalStoryPointsCompleted(int totalStoryPointsCompleted) { this.totalStoryPointsCompleted = totalStoryPointsCompleted; }
    public double getAverageProductivityScore() { return averageProductivityScore; }
    public void setAverageProductivityScore(double averageProductivityScore) { this.averageProductivityScore = averageProductivityScore; }
    public double getDeploymentFrequency() { return deploymentFrequency; }
    public void setDeploymentFrequency(double deploymentFrequency) { this.deploymentFrequency = deploymentFrequency; }
    public double getLeadTimeForChanges() { return leadTimeForChanges; }
    public void setLeadTimeForChanges(double leadTimeForChanges) { this.leadTimeForChanges = leadTimeForChanges; }
    public double getChangeFailureRate() { return changeFailureRate; }
    public void setChangeFailureRate(double changeFailureRate) { this.changeFailureRate = changeFailureRate; }
    public List<DeveloperReportDto> getDeveloperReports() { return developerReports; }
    public void setDeveloperReports(List<DeveloperReportDto> developerReports) { this.developerReports = developerReports; }
}