package com.productvity.mtool.service;
import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.productvity.mtool.entity.Developer;


@Service
public class SchedulerService {

    private static final Logger logger = LoggerFactory.getLogger(SchedulerService.class);

    @Autowired
    private GithubService githubService;
    @Autowired
    private JiraService jiraService;
    @Autowired
    private DeveloperService developerService;
    @Autowired
    private ProductivityCalculationService productivityCalculationService;

    @Value("${github.owner}")
    private String githubOwner;
    @Value("${github.repo}")
    private String githubRepo;
    @Value("${github.token}")
    private String githubToken;

    @Value("${jira.project-key}")
    private String jiraProjectKey;
    @Value("${jira.email}")
    private String jiraApiEmail;
    @Value("${jira.token}")
    private String jiraApiToken;

    @Scheduled(cron = "0 0 1 * * ?") // Runs daily at 1 AM
    public void dailyProductivityAggregationTask() {
        logger.info("Starting daily productivity aggregation task...");
        LocalDate yesterday = LocalDate.now().minusDays(1);
        syncNow(yesterday);
        logger.info("Daily productivity aggregation task completed.");
    }

    public void syncNow(LocalDate date) {
        logger.info("Initiating data synchronization for date: {}", date);

        List<Developer> developers = developerService.getAllDevelopers();

        for (Developer developer : developers) {
            if (developer.getGithubUsername() != null && !developer.getGithubUsername().isEmpty()) {
                logger.debug("Fetching GitHub data for developer: {}", developer.getEmail());
                githubService.fetchCommits(githubOwner, githubRepo, githubToken, developer.getEmail());
            } else {
                logger.debug("Developer {} has no GitHub username, skipping GitHub fetch.", developer.getEmail());
            }

            if (developer.getJiraUsername() != null && !developer.getJiraUsername().isEmpty()) {
                logger.debug("Fetching Jira data for developer: {}", developer.getEmail());
                jiraService.fetchIssues(jiraProjectKey, jiraApiEmail, jiraApiToken, developer.getEmail());
            } else {
                logger.debug("Developer {} has no Jira username, skipping Jira fetch.", developer.getEmail());
            }
        }

        productivityCalculationService.calculateAndSaveDailyProductivity(date);
        productivityCalculationService.generateCeoReports(date);

        logger.info("Data synchronization for date {} completed.", date);
    }
}
