package com.productvity.mtool.Repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.productvity.mtool.entity.DailyProductivity;

@Repository
public interface ProductivityRepository extends JpaRepository<DailyProductivity, Long> {
    List<DailyProductivity> findByDeveloperIdAndDate(Long developerId, LocalDate date);
    List<DailyProductivity> findByDeveloperId(Long developerId);
    List<DailyProductivity> findByDeveloperTeamIdAndDate(Long teamId, LocalDate date);
    void deleteAllByDate(LocalDate date);
}
