package com.productvity.mtool.controller;

import com.productvity.mtool.dto.CeoReportDto;
import com.productvity.mtool.service.ReportsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportsService reportService;

    @GetMapping
    public List<CeoReportDto> getAllReports() {
        return reportService.getAllReports();
    }

    @GetMapping("/team/{teamId}")
    public ResponseEntity<List<CeoReportDto>> getReportsByTeam(@PathVariable Long teamId) {
        List<CeoReportDto> reports = reportService.getReportsByTeam(teamId);
        if (!reports.isEmpty()) {
            return ResponseEntity.ok(reports);
        }
        return ResponseEntity.notFound().build();
    }
}