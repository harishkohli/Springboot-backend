package com.productvity.mtool.service;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Collections;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.productvity.mtool.Repository.DeveloperRepository;
import com.productvity.mtool.Repository.JiraActivityRepository;
import com.productvity.mtool.entity.Developer;
import com.productvity.mtool.entity.JiraActivity;

@Service
public class JiraService {

    private static final Logger logger = LoggerFactory.getLogger(JiraService.class);

    @Autowired
    private JiraActivityRepository jiraActivityRepository;

    @Autowired
    private DeveloperRepository developerRepository;

    @Value("${jira.base-url}")
    private String jiraBaseUrl;
    @Value("${jira.story-points-field:customfield_10016}")
    private String storyPointsField;

    private final RestTemplate restTemplate = new RestTemplate();

    @Transactional
    public void fetchIssues(String projectKey, String apiEmail, String apiToken, String developerEmail) {
        Developer developer = developerRepository.findByEmail(developerEmail);
        // **UPDATED**: Check for jiraAccountId instead of jiraUsername
        if (developer == null || developer.getJiraAccountId() == null || developer.getJiraAccountId().isEmpty()) {
            logger.info("Developer {} has no Jira Account ID configured or does not exist, skipping Jira fetch.", developerEmail);
            return;
        }

        // **UPDATED**: Use jiraAccountId in the JQL query for the 'assignee' field.
        String jqlQuery = String.format("project = \"%s\" AND assignee = \"%s\" ORDER BY updated DESC",
                projectKey, developer.getJiraAccountId());
        
        String encodedJql = URLEncoder.encode(jqlQuery, StandardCharsets.UTF_8);
        String url = String.format("%s/rest/api/3/search?jql=%s&fields=summary,status,timespent,resolutiondate,%s",
                jiraBaseUrl, encodedJql, storyPointsField);

        HttpHeaders headers = new HttpHeaders();
        String auth = apiEmail + ":" + apiToken;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        headers.set("Authorization", "Basic " + encodedAuth);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        HttpEntity<String> entity = new HttpEntity<>(headers);
        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(url, HttpMethod.GET, entity, JsonNode.class);
            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                JsonNode issues = response.getBody().get("issues");
                if (issues != null) {
                    for (JsonNode issue : issues) {
                        String issueKey = issue.get("key").asText();
                        Optional<JiraActivity> existingActivityOpt = jiraActivityRepository.findByIssueKeyAndDeveloperId(issueKey, developer.getId());
                        JiraActivity activity = existingActivityOpt.orElse(new JiraActivity());

                        if (activity.getId() == null) {
                            activity.setDeveloper(developer);
                            activity.setIssueKey(issueKey);
                        }

                        JsonNode fields = issue.get("fields");
                        activity.setIssueSummary(fields.get("summary").asText());
                        activity.setStatus(fields.get("status").get("name").asText());
                        activity.setTimeSpentMinutes(fields.hasNonNull("timespent") ? fields.get("timespent").asInt() / 60 : 0);
                        activity.setStoryPoints(fields.hasNonNull(storyPointsField) ? fields.get(storyPointsField).asInt(0) : 0);

                        JsonNode resolutionDateNode = fields.get("resolutiondate");
                        if (resolutionDateNode != null && !resolutionDateNode.isNull()) {
                            activity.setCompletedDate(ZonedDateTime.parse(resolutionDateNode.asText(), DateTimeFormatter.ISO_DATE_TIME));
                        } else {
                            activity.setCompletedDate(null);
                        }

                        jiraActivityRepository.save(activity);
                        String action = existingActivityOpt.isPresent() ? "Updated" : "Saved new";
                        logger.debug("{} Jira activity for developer {}: {} ({} story points)", action, developer.getEmail(), activity.getIssueKey(), activity.getStoryPoints());
                    }
                }
            }
        } catch (Exception e) {
            logger.error("An unexpected error occurred while fetching Jira issues for project {}: {}", projectKey, e.getMessage());
        }
    }
}