package com.productvity.mtool.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.productvity.mtool.entity.DailyProductivity;
import com.productvity.mtool.service.ProductivityService;

@RestController
@RequestMapping("/api/productivity")
public class ProductivityController {

    @Autowired
    private ProductivityService productivityService;

    @GetMapping("/developer/{developerId}")
    public ResponseEntity<List<DailyProductivity>> getDeveloperProductivity(@PathVariable Long developerId) {
        List<DailyProductivity> productivityData = productivityService.getDailyProductivityForDeveloper(developerId);
        if (productivityData != null && !productivityData.isEmpty()) {
            return ResponseEntity.ok(productivityData);
        }
        return ResponseEntity.notFound().build();
    }
}
