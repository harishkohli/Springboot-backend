package com.productvity.mtool.entity;

import jakarta.persistence.*;
import java.time.ZonedDateTime;

@Entity
@Table(name = "github_activities")
public class GithubActivity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "developer_id")
    private Developer developer;

    private String repoName;

    @Column(unique = true)
    private String commitHash;

    @Column(length = 1000)
    private String commitMessage;

    private ZonedDateTime commitDate;

    private String prId;
    private String prStatus;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Developer getDeveloper() { return developer; }
    public void setDeveloper(Developer developer) { this.developer = developer; }
    public String getRepoName() { return repoName; }
    public void setRepoName(String repoName) { this.repoName = repoName; }
    public String getCommitHash() { return commitHash; }
    public void setCommitHash(String commitHash) { this.commitHash = commitHash; }
    public String getCommitMessage() { return commitMessage; }
    public void setCommitMessage(String commitMessage) { this.commitMessage = commitMessage; }
    public ZonedDateTime getCommitDate() { return commitDate; }
    public void setCommitDate(ZonedDateTime commitDate) { this.commitDate = commitDate; }
    public String getPrId() { return prId; }
    public void setPrId(String prId) { this.prId = prId; }
    public String getPrStatus() { return prStatus; }
    public void setPrStatus(String prStatus) { this.prStatus = prStatus; }
}
