package com.productvity.mtool.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.productvity.mtool.Repository.DeveloperRepository;
import com.productvity.mtool.Repository.TeamRepository;
import com.productvity.mtool.entity.Developer;
import com.productvity.mtool.entity.Team;

@Service
public class TeamService {

    @Autowired
    private TeamRepository teamRepository;

    @Autowired
    private DeveloperRepository developerRepository;

    public List<Team> getAllTeams() {
        return teamRepository.findAll();
    }

    @Transactional
    public Team saveTeam(Team team) {
        return teamRepository.save(team);
    }

    public Team getTeamById(Long id) {
        return teamRepository.findById(id).orElse(null);
    }

    @Transactional
    public Team updateTeam(Long id, Team updatedTeam) {
        Optional<Team> existing = teamRepository.findById(id);
        if (existing.isPresent()) {
            Team team = existing.get();
            team.setName(updatedTeam.getName());
            team.setManagerName(updatedTeam.getManagerName());
            return teamRepository.save(team);
        }
        return null;
    }

    @Transactional
    public void deleteTeam(Long id) {
        teamRepository.deleteById(id);
    }

    @Transactional
    public Team updateTeamMembers(Long teamId, List<Long> developerIds) {
        Team team = teamRepository.findById(teamId)
                .orElseThrow(() -> new RuntimeException("Team not found with id: " + teamId));

        // Un-assign all current developers from this team
        // This is important to handle developers who are removed from the team.
        List<Developer> currentMembers = developerRepository.findByTeam(team);
        for (Developer member : currentMembers) {
            member.setTeam(null);
        }
        developerRepository.saveAll(currentMembers); // Save changes for removed members

        // Assign the new set of developers to this team
        List<Developer> newMembers = developerRepository.findAllById(developerIds);
        for (Developer newMember : newMembers) {
            newMember.setTeam(team);
        }
        developerRepository.saveAll(newMembers); // Save changes for new/existing members

        // Eagerly fetch the updated team to return it with the updated member list
        return teamRepository.findById(teamId).get();
    }
}