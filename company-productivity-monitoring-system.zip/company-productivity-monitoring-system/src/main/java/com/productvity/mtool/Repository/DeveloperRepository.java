package com.productvity.mtool.Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.productvity.mtool.entity.Developer;
import com.productvity.mtool.entity.Team;

@Repository
public interface DeveloperRepository extends JpaRepository<Developer, Long> {
    Developer findByGithubUsername(String githubUsername);
    Developer findByJiraUsername(String jiraUsername);
    Developer findByEmail(String email);
    // **NEW METHOD to find developers by team**
    List<Developer> findByTeam(Team team);
}