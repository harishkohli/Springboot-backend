package com.productvity.mtool.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "daily_productivity")
public class DailyProductivity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "developer_id")
    @JsonIgnore
    private Developer developer;

    private LocalDate date;
    private int commits;
    private int pullRequests;
    private int issuesClosed;
    private int codeReviews;
    private int jiraTasksCompleted;
    private int bugsFixed;
    private int deploymentCount;
    private int storyPointsCompleted;
    private double cycleTime; // in hours
    private double changeFailureRate; // in percentage

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Developer getDeveloper() { return developer; }
    public void setDeveloper(Developer developer) { this.developer = developer; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    public int getCommits() { return commits; }
    public void setCommits(int commits) { this.commits = commits; }
    public int getPullRequests() { return pullRequests; }
    public void setPullRequests(int pullRequests) { this.pullRequests = pullRequests; }
    public int getIssuesClosed() { return issuesClosed; }
    public void setIssuesClosed(int issuesClosed) { this.issuesClosed = issuesClosed; }
    public int getCodeReviews() { return codeReviews; }
    public void setCodeReviews(int codeReviews) { this.codeReviews = codeReviews; }
    public int getJiraTasksCompleted() { return jiraTasksCompleted; }
    public void setJiraTasksCompleted(int jiraTasksCompleted) { this.jiraTasksCompleted = jiraTasksCompleted; }
    public int getBugsFixed() { return bugsFixed; }
    public void setBugsFixed(int bugsFixed) { this.bugsFixed = bugsFixed; }
    public int getDeploymentCount() { return deploymentCount; }
    public void setDeploymentCount(int deploymentCount) { this.deploymentCount = deploymentCount; }
    public int getStoryPointsCompleted() { return storyPointsCompleted; }
    public void setStoryPointsCompleted(int storyPointsCompleted) { this.storyPointsCompleted = storyPointsCompleted; }
    public double getCycleTime() { return cycleTime; }
    public void setCycleTime(double cycleTime) { this.cycleTime = cycleTime; }
    public double getChangeFailureRate() { return changeFailureRate; }
    public void setChangeFailureRate(double changeFailureRate) { this.changeFailureRate = changeFailureRate; }
}