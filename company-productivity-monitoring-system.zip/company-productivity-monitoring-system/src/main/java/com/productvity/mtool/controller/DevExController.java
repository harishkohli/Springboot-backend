package com.productvity.mtool.controller;

import com.productvity.mtool.dto.DevExSurveyResponseDto;
import com.productvity.mtool.dto.DevExSurveySubmissionDto;
import com.productvity.mtool.service.DevExService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/devex")
public class DevExController {

    @Autowired
    private DevExService devExService;

    @PostMapping("/survey")
    public ResponseEntity<?> submitSurvey(@RequestBody DevExSurveySubmissionDto surveyDto, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return new ResponseEntity<>("User is not authenticated", HttpStatus.UNAUTHORIZED);
        }

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        String email = userDetails.getUsername();

        try {
            devExService.saveSurvey(surveyDto, email);
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // **NEW ENDPOINT TO GET ALL SURVEYS FOR THE CEO**
    @GetMapping("/surveys")
    @PreAuthorize("hasRole('ROLE_CEO')") // Secures the endpoint so only CEOs can access it
    public ResponseEntity<List<DevExSurveyResponseDto>> getAllSurveys() {
        List<DevExSurveyResponseDto> surveys = devExService.getAllSurveys();
        return ResponseEntity.ok(surveys);
    }
}