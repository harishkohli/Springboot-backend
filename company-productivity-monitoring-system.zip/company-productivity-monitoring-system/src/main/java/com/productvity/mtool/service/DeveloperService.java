package com.productvity.mtool.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.productvity.mtool.Repository.DeveloperRepository;
import com.productvity.mtool.entity.Developer;


@Service
public class DeveloperService {

    @Autowired
    private DeveloperRepository developerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<Developer> getAllDevelopers() {
        return developerRepository.findAll();
    }

    @Transactional
    public Developer saveDeveloper(Developer developer) {
        return developerRepository.save(developer);
    }

    @Transactional
    public Developer saveDeveloper(Developer developer, String rawPassword) {
        if (rawPassword != null && !rawPassword.isEmpty()) {
            developer.setPassword(passwordEncoder.encode(rawPassword));
        }
        return developerRepository.save(developer);
    }

    public Developer getDeveloperById(Long id) {
        return developerRepository.findById(id).orElse(null);
    }

    public Developer findByEmail(String email) {
        return developerRepository.findByEmail(email);
    }

    @Transactional
    public Developer updateDeveloper(Long id, Developer updatedDeveloper) {
        Optional<Developer> existing = developerRepository.findById(id);
        if (existing.isPresent()) {
            Developer dev = existing.get();
            dev.setName(updatedDeveloper.getName());
            dev.setEmail(updatedDeveloper.getEmail());
            if (updatedDeveloper.getPassword() != null && !updatedDeveloper.getPassword().isEmpty()) {
                dev.setPassword(passwordEncoder.encode(updatedDeveloper.getPassword()));
            }
            dev.setGithubUsername(updatedDeveloper.getGithubUsername());
            dev.setJiraUsername(updatedDeveloper.getJiraUsername());
            dev.setJiraAccountId(updatedDeveloper.getJiraAccountId()); // <-- ADDED THIS LINE
            dev.setRole(updatedDeveloper.getRole());
            dev.setTeam(updatedDeveloper.getTeam());
            return developerRepository.save(dev);
        }
        return null;
    }

    @Transactional
    public void deleteDeveloper(Long id) {
        developerRepository.deleteById(id);
    }
}