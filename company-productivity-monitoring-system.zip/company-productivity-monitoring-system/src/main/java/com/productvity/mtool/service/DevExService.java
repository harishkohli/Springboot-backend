package com.productvity.mtool.service;

import com.productvity.mtool.Repository.DeveloperRepository;
import com.productvity.mtool.Repository.DevExSurveyRepository;
import com.productvity.mtool.dto.DevExSurveyResponseDto;
import com.productvity.mtool.dto.DevExSurveySubmissionDto;
import com.productvity.mtool.entity.Developer;
import com.productvity.mtool.entity.DevExSurvey;
import com.productvity.mtool.entity.DevExSurveyResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DevExService {

    @Autowired
    private DevExSurveyRepository devExSurveyRepository;

    @Autowired
    private DeveloperRepository developerRepository;

    @Transactional
    public void saveSurvey(DevExSurveySubmissionDto surveyDto, String developerEmail) {
        Developer developer = developerRepository.findByEmail(developerEmail);
        if (developer == null) {
            throw new RuntimeException("Developer not found for email: " + developerEmail);
        }

        DevExSurvey survey = new DevExSurvey();
        survey.setDeveloper(developer);
        survey.setSubmissionDate(LocalDate.now());
        survey.setFeedback(surveyDto.getFeedback());

        List<DevExSurveyResponse> responses = new ArrayList<>();
        for (DevExSurveySubmissionDto.RatingDto ratingDto : surveyDto.getRatings()) {
            DevExSurveyResponse response = new DevExSurveyResponse();
            response.setQuestionId(ratingDto.getQuestionId());
            response.setRating(ratingDto.getRating());
            response.setSurvey(survey);
            responses.add(response);
        }

        survey.setResponses(responses);
        devExSurveyRepository.save(survey);
    }

    // **NEW METHOD TO FETCH ALL SURVEYS FOR THE CEO DASHBOARD**
    @Transactional(readOnly = true) // Use read-only transaction for fetching data
    public List<DevExSurveyResponseDto> getAllSurveys() {
        List<DevExSurvey> surveys = devExSurveyRepository.findAll();
        return surveys.stream().map(this::mapToDto).collect(Collectors.toList());
    }

    // Helper method to convert the entity to a DTO
    private DevExSurveyResponseDto mapToDto(DevExSurvey survey) {
        DevExSurveyResponseDto dto = new DevExSurveyResponseDto();
        dto.setId(survey.getId());
        // Eagerly fetch developer name to prevent lazy loading issues
        dto.setDeveloperName(survey.getDeveloper().getName());
        dto.setSubmissionDate(survey.getSubmissionDate());
        dto.setFeedback(survey.getFeedback());

        List<DevExSurveyResponseDto.RatingDto> ratingDtos = survey.getResponses().stream().map(response -> {
            DevExSurveyResponseDto.RatingDto ratingDto = new DevExSurveyResponseDto.RatingDto();
            ratingDto.setQuestionId(response.getQuestionId());
            ratingDto.setRating(response.getRating());
            return ratingDto;
        }).collect(Collectors.toList());

        dto.setResponses(ratingDtos);
        return dto;
    }
}