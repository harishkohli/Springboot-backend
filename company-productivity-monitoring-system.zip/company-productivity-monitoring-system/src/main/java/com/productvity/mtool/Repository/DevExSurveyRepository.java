package com.productvity.mtool.Repository;

import com.productvity.mtool.entity.DevExSurvey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DevExSurveyRepository extends JpaRepository<DevExSurvey, Long> {
}