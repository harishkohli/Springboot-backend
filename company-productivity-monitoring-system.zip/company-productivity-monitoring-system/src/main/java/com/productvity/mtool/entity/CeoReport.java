package com.productvity.mtool.entity;


import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class CeoReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate reportDate;

    @ManyToOne(fetch = FetchType.EAGER) // FIX: Changed from LAZY to EAGER to prevent proxy serialization errors.
    @JoinColumn(name = "team_id")
    private Team team;

    private int totalCommits;
    private int totalTasksCompleted;
    private int totalDeployments;
    private int totalStoryPointsCompleted;
    private double averageProductivityScore;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getReportDate() {
        return reportDate;
    }

    public void setReportDate(LocalDate reportDate) {
        this.reportDate = reportDate;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public int getTotalCommits() {
        return totalCommits;
    }

    public void setTotalCommits(int totalCommits) {
        this.totalCommits = totalCommits;
    }

    public int getTotalTasksCompleted() {
        return totalTasksCompleted;
    }

    public void setTotalTasksCompleted(int totalTasksCompleted) {
        this.totalTasksCompleted = totalTasksCompleted;
    }

    public int getTotalDeployments() {
        return totalDeployments;
    }

    public void setTotalDeployments(int totalDeployments) {
        this.totalDeployments = totalDeployments;
    }

    public double getAverageProductivityScore() {
        return averageProductivityScore;
    }

    public void setAverageProductivityScore(double averageProductivityScore) {
        this.averageProductivityScore = averageProductivityScore;
    }

    public int getTotalStoryPointsCompleted() {
        return totalStoryPointsCompleted;
    }

    public void setTotalStoryPointsCompleted(int totalStoryPointsCompleted) {
        this.totalStoryPointsCompleted = totalStoryPointsCompleted;
    }
}