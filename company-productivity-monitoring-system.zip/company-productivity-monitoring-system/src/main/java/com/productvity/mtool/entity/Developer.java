package com.productvity.mtool.entity;

import jakarta.persistence.*;
import lombok.ToString;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name = "developers")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Developer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    @Column(unique = true, nullable = false)
    private String email;
    @Column(nullable = false)
    private String password;
    private String githubUsername;
    private String jiraUsername;
    private String jiraAccountId;
    @Column(nullable = false)
    private String role;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "team_id")
    private Team team;

    @OneToMany(mappedBy = "developer", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @ToString.Exclude
    private List<DailyProductivity> dailyProductivities;

    @OneToMany(mappedBy = "developer", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @ToString.Exclude
    private List<GithubActivity> githubActivities;

    @OneToMany(mappedBy = "developer", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @ToString.Exclude
    private List<JiraActivity> jiraActivities;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getGithubUsername() { return githubUsername; }
    public void setGithubUsername(String githubUsername) { this.githubUsername = githubUsername; }
    public String getJiraUsername() { return jiraUsername; }
    public void setJiraUsername(String jiraUsername) { this.jiraUsername = jiraUsername; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public Team getTeam() { return team; }
    public void setTeam(Team team) { this.team = team; }
    public List<DailyProductivity> getDailyProductivities() { return dailyProductivities; }
    public void setDailyProductivities(List<DailyProductivity> dailyProductivities) { this.dailyProductivities = dailyProductivities; }
    public List<GithubActivity> getGithubActivities() { return githubActivities; }
    public void setGithubActivities(List<GithubActivity> githubActivities) { this.githubActivities = githubActivities; }
    public List<JiraActivity> getJiraActivities() { return jiraActivities; }
    public void setJiraActivities(List<JiraActivity> jiraActivities) { this.jiraActivities = jiraActivities; }
    public String getJiraAccountId() { return jiraAccountId; }
    public void setJiraAccountId(String jiraAccountId) { this.jiraAccountId = jiraAccountId; }
}