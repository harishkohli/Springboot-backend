package com.productvity.mtool.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.productvity.mtool.service.SchedulerService;

@RestController
@RequestMapping("/api/data")
public class DataSyncController {	

    @Autowired
    private SchedulerService schedulerService;

    @PostMapping("/sync-now")
    public ResponseEntity<String> syncDataNow() {
        LocalDate today = LocalDate.now();
        schedulerService.syncNow(today);
        return ResponseEntity.ok("Data synchronization initiated for today.");
    }
}
