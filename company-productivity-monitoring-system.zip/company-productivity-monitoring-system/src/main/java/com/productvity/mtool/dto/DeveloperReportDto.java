package com.productvity.mtool.dto;

public class DeveloperReportDto {

    private Long developerId;
    private String developerName;
    private int totalCommits;
    private int totalTasksCompleted;
    private double productivityScore;
    private double deploymentFrequency; // per week
    private double leadTimeForChanges; // in hours
    private double changeFailureRate; // percentage

    // Getters and Setters
    public Long getDeveloperId() { return developerId; }
    public void setDeveloperId(Long developerId) { this.developerId = developerId; }
    public String getDeveloperName() { return developerName; }
    public void setDeveloperName(String developerName) { this.developerName = developerName; }
    public int getTotalCommits() { return totalCommits; }
    public void setTotalCommits(int totalCommits) { this.totalCommits = totalCommits; }
    public int getTotalTasksCompleted() { return totalTasksCompleted; }
    public void setTotalTasksCompleted(int totalTasksCompleted) { this.totalTasksCompleted = totalTasksCompleted; }
    public double getProductivityScore() { return productivityScore; }
    public void setProductivityScore(double productivityScore) { this.productivityScore = productivityScore; }
    public double getDeploymentFrequency() { return deploymentFrequency; }
    public void setDeploymentFrequency(double deploymentFrequency) { this.deploymentFrequency = deploymentFrequency; }
    public double getLeadTimeForChanges() { return leadTimeForChanges; }
    public void setLeadTimeForChanges(double leadTimeForChanges) { this.leadTimeForChanges = leadTimeForChanges; }
    public double getChangeFailureRate() { return changeFailureRate; }
    public void setChangeFailureRate(double changeFailureRate) { this.changeFailureRate = changeFailureRate; }
}