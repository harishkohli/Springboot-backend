package com.productvity.mtool.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productvity.mtool.Repository.ProductivityRepository;
import com.productvity.mtool.entity.DailyProductivity;

@Service
public class ProductivityService {

    @Autowired
    private ProductivityRepository productivityRepository;

    public List<DailyProductivity> getDailyProductivityForDeveloper(Long developerId) {
        return productivityRepository.findByDeveloperId(developerId);
    }
}
