package com.productvity.mtool.service;

import com.productvity.mtool.dto.CeoReportDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReportsService {

    @Autowired
    private ProductivityCalculationService productivityCalculationService;

    public List<CeoReportDto> getAllReports() {
        // We'll generate the report for the most recent day with data, typically 'today' or 'yesterday'
        return productivityCalculationService.getCeoReportDtos(LocalDate.now());
    }

    public List<CeoReportDto> getReportsByTeam(Long teamId) {
        return getAllReports().stream()
                .filter(report -> report.getTeamId().equals(teamId))
                .collect(Collectors.toList());
    }
}