package com.productvity.mtool.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.productvity.mtool.entity.JiraActivity;

@Repository
public interface JiraActivityRepository extends JpaRepository<JiraActivity, Long> {
    List<JiraActivity> findByDeveloperId(Long developerId);
    Optional<JiraActivity> findByIssueKeyAndDeveloperId(String issueKey, Long developerId);
}
