package com.productvity.mtool.dto;

import java.time.LocalDate;
import java.util.List;

// This DTO is used to send survey results to the frontend.
public class DevExSurveyResponseDto {

    private Long id;
    private String developerName;
    private LocalDate submissionDate;
    private String feedback;
    private List<RatingDto> responses;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDeveloperName() {
        return developerName;
    }

    public void setDeveloperName(String developerName) {
        this.developerName = developerName;
    }

    public LocalDate getSubmissionDate() {
        return submissionDate;
    }

    public void setSubmissionDate(LocalDate submissionDate) {
        this.submissionDate = submissionDate;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public List<RatingDto> getResponses() {
        return responses;
    }

    public void setResponses(List<RatingDto> responses) {
        this.responses = responses;
    }

    // Inner class for individual question ratings
    public static class RatingDto {
        private String questionId;
        private int rating;

        public String getQuestionId() {
            return questionId;
        }

        public void setQuestionId(String questionId) {
            this.questionId = questionId;
        }

        public int getRating() {
            return rating;
        }

        public void setRating(int rating) {
            this.rating = rating;
        }
    }
}