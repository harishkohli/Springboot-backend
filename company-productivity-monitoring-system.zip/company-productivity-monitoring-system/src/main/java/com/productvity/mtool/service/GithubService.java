package com.productvity.mtool.service;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.productvity.mtool.Repository.DeveloperRepository;
import com.productvity.mtool.Repository.GithubActivityRepository;
import com.productvity.mtool.entity.Developer;
import com.productvity.mtool.entity.GithubActivity;

@Service
public class GithubService {

    private static final Logger logger = LoggerFactory.getLogger(GithubService.class);

    @Autowired
    private GithubActivityRepository githubActivityRepository;

    @Autowired
    private DeveloperRepository developerRepository;

    @Value("${github.base-url:https://api.github.com}")
    private String githubBaseUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    private HttpHeaders createGithubHeaders(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("X-GitHub-Api-Version", "2022-11-28");
        return headers;
    }

    private List<String> fetchAllBranchNames(String owner, String repo, String token) {
        String url = String.format("%s/repos/%s/%s/branches", githubBaseUrl, owner, repo);
        HttpEntity<String> entity = new HttpEntity<>(createGithubHeaders(token));
        List<String> branchNames = new ArrayList<>();
        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(url, HttpMethod.GET, entity, JsonNode.class);
            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                for (JsonNode branchNode : response.getBody()) {
                    branchNames.add(branchNode.get("name").asText());
                }
            }
            logger.info("Fetched {} branches for repo {}/{}", branchNames.size(), owner, repo);
        } catch (Exception e) {
            logger.error("An unexpected error occurred while fetching GitHub branches for {}/{}: {}", owner, repo, e.getMessage());
        }
        return branchNames;
    }

    @Transactional
    public void fetchCommits(String owner, String repo, String token, String developerEmail) {
        Developer developer = developerRepository.findByEmail(developerEmail);
        if (developer == null || developer.getGithubUsername() == null || developer.getGithubUsername().isBlank()) {
            logger.warn("Developer not found or has no GitHub username for email: {}", developerEmail);
            return;
        }

        List<String> branches = fetchAllBranchNames(owner, repo, token);
        if (branches.isEmpty()) {
            logger.warn("No branches found for repo {}/{}, cannot fetch commits.", owner, repo);
            return;
        }

        for (String branch : branches) {
            fetchCommitsForBranch(owner, repo, token, developer, branch);
        }
    }

    private void fetchCommitsForBranch(String owner, String repo, String token, Developer developer, String branch) {
        // **FIX:** Fetch commits by a specific author (developer's GitHub username) for reliability.
        String url = UriComponentsBuilder.fromHttpUrl(githubBaseUrl)
                .path("/repos/{owner}/{repo}/commits")
                .queryParam("sha", branch)
                .queryParam("author", developer.getGithubUsername())
                .buildAndExpand(owner, repo)
                .toUriString();
        
        HttpEntity<String> entity = new HttpEntity<>(createGithubHeaders(token));
        ResponseEntity<JsonNode> response;
        try {
            response = restTemplate.exchange(url, HttpMethod.GET, entity, JsonNode.class);
            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                for (JsonNode commitNode : response.getBody()) {
                    String commitHash = commitNode.get("sha").asText();

                    if (githubActivityRepository.findByCommitHash(commitHash).isPresent()) {
                        continue; // Skip already saved commits
                    }

                    // Since we are querying by author, we can be confident this commit belongs to the developer.
                    GithubActivity activity = new GithubActivity();
                    activity.setDeveloper(developer);
                    activity.setRepoName(repo);
                    activity.setCommitHash(commitHash);
                    activity.setCommitMessage(commitNode.get("commit").get("message").asText());

                    JsonNode authorNode = commitNode.get("commit").get("author");
                    String dateStr = authorNode.get("date").asText();
                    ZonedDateTime commitDate = ZonedDateTime.parse(dateStr, DateTimeFormatter.ISO_DATE_TIME);
                    activity.setCommitDate(commitDate);

                    String commitMessage = activity.getCommitMessage();
                    if (commitMessage != null && commitMessage.matches(".*Merge pull request #(\\d+).*")) {
                        String prId = commitMessage.replaceAll(".*Merge pull request #(\\d+).*", "$1");
                        activity.setPrId(prId);
                        activity.setPrStatus("Merged");
                    }
                    githubActivityRepository.save(activity);
                    logger.debug("Saved new GitHub activity on branch '{}' for developer {}: {}", branch, developer.getEmail(), activity.getCommitHash());
                }
            }
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains("ConstraintViolationException")) {
                logger.warn("A commit conflict occurred, which is expected during concurrent syncs. The unique constraint prevented a duplicate entry.");
            } else {
                logger.error("An unexpected error occurred while fetching GitHub commits for {}/{} on branch {}: {}", owner, repo, branch, e.getMessage());
            }
        }
    }
}