package com.productvity.mtool.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.productvity.mtool.entity.GithubActivity;

@Repository
public interface GithubActivityRepository extends JpaRepository<GithubActivity, Long> {
    List<GithubActivity> findByDeveloperId(Long developerId);
    Optional<GithubActivity> findByCommitHash(String commitHash);
}