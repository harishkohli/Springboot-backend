// FIX: Create the models file to define data structures used throughout the application.
export interface User {
  id: number;
  name: string;
  email: string;
  role: 'CEO' | 'MANAGER' | 'DEVELOPER';
  team?: Team | null; // A developer or manager might belong to a team
  githubUsername?: string;
}

export interface Team {
  id: number;
  name?: string;
}

export interface Developer {
  id: number;
  name: string;
  teamId: number;
  email: string; // Add email to uniquely identify developers
  role: string;
}

export interface DailyProductivity {
  date: string; // "YYYY-MM-DD"
  commits: number;
  pullRequests: number;
  tasksCompleted: number; // Renamed from jiraTasksCompleted
  bugsFixed: number;
  storyPointsCompleted: number;
  // DORA-inspired metrics
  deploymentCount: number;
  cycleTime: number; // in hours (first commit to merge)
  changeFailureRate: number; // percentage
}

export interface DeveloperReport {
    developerId: number;
    developerName: string;
    totalCommits: number;
    totalTasksCompleted: number;
    productivityScore: number;
    deploymentFrequency: number;
    leadTimeForChanges: number;
    changeFailureRate: number;
}

export interface CeoReport {
  teamId: number;
  teamName: string;
  totalCommits: number;
  totalTasksCompleted: number;
  averageProductivityScore: number;
  developerReports: DeveloperReport[];
  totalStoryPointsCompleted: number;
  deploymentFrequency: number; // deployments per week
  leadTimeForChanges: number; // in hours
  changeFailureRate: number; // percentage (e.g., 5 for 5%)
}

export interface DevExSurveyRating {
  questionId: string;
  rating: number;
}

export interface DevExSurveySubmission {
  id: number;
  developerName: string;
  submissionDate: string; // "YYYY-MM-DD"
  feedback: string;
  responses: DevExSurveyRating[];
}