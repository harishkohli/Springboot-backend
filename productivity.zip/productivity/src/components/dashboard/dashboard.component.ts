import { Component, ChangeDetectionStrategy, inject, signal, OnInit, computed } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { CeoReport, DailyProductivity } from '../../models';
import { BarChartComponent } from '../charts/bar-chart.component';
import { LineChartComponent } from '../charts/line-chart.component';
import { AiAnalystComponent } from '../ai-analyst/ai-analyst.component';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    DecimalPipe,
    BarChartComponent,
    LineChartComponent,
    AiAnalystComponent,
  ],
  template: `
    <div class="space-y-8">
      <header class="flex flex-wrap justify-between items-center gap-4">
        <div>
          <h1 class="text-3xl font-bold text-white">Dashboard</h1>
          <p class="text-lg text-gray-400">Welcome, {{ currentUser()?.name }}. Here's your performance overview.</p>
        </div>
        <div class="flex items-center gap-4">
          @if (currentUser()?.role === 'CEO' || currentUser()?.role === 'MANAGER') {
            <button (click)="openAiAnalyst()" class="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-md flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                Ask AI Analyst
            </button>
          }
          <button (click)="syncData()" [disabled]="isSyncing()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-md disabled:bg-indigo-900/50 disabled:cursor-not-allowed flex items-center">
            @if(isSyncing()) {
              <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span>Syncing...</span>
            } @else {
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 110 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd" />
              </svg>
              <span>Sync Data</span>
            }
          </button>
        </div>
      </header>
      
      <main>
        @if (loading()) {
          <div class="flex justify-center items-center p-8">
              <svg class="animate-spin h-10 w-10 text-indigo-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
          </div>
        } @else if (error()) {
          <div class="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline">{{ error() }}</span>
          </div>
        } @else {
          @switch (currentUser()?.role) {
            @case ('CEO') {
              <div class="space-y-8">
                <section>
                  <h2 class="text-2xl font-semibold text-gray-200 mb-4">Team Performance Overview</h2>
                  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    @for (report of ceoReports(); track report.teamId) {
                      <div class="bg-gray-800 p-4 rounded-lg">
                        <h3 class="font-bold text-lg text-indigo-400">{{ report.teamName }}</h3>
                        <p class="text-sm text-gray-400">Avg. Productivity: <span class="font-semibold text-white">{{ report.averageProductivityScore | number:'1.1-2' }}</span></p>
                        <p class="text-sm text-gray-400">Total Commits: <span class="font-semibold text-white">{{ report.totalCommits }}</span></p>
                      </div>
                    } @empty {
                      <p class="text-gray-400 col-span-full">No team reports available.</p>
                    }
                  </div>
                </section>
                <section>
                    <h2 class="text-2xl font-semibold text-gray-200 mb-4">Productivity Scores by Team</h2>
                    <div class="bg-gray-800 p-6 rounded-lg">
                        <app-bar-chart [data]="teamProductivityChartData()"></app-bar-chart>
                    </div>
                </section>
              </div>
            }
            @case ('MANAGER') {
              <div class="space-y-8">
                @if(managerReport(); as report) {
                    <h2 class="text-2xl font-semibold text-gray-200">Team Report: {{ report.teamName }}</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div class="bg-gray-800 p-4 rounded-lg"><p class="text-sm text-gray-400">Deployment Frequency</p><p class="text-2xl font-bold text-white">{{ report.deploymentFrequency | number:'1.1-1' }}/wk</p></div>
                        <div class="bg-gray-800 p-4 rounded-lg"><p class="text-sm text-gray-400">Lead Time for Changes</p><p class="text-2xl font-bold text-white">{{ report.leadTimeForChanges | number:'1.1-1' }}h</p></div>
                        <div class="bg-gray-800 p-4 rounded-lg"><p class="text-sm text-gray-400">Change Failure Rate</p><p class="text-2xl font-bold text-white">{{ report.changeFailureRate | number:'1.1-1' }}%</p></div>
                        <div class="bg-gray-800 p-4 rounded-lg"><p class="text-sm text-gray-400">Avg. Productivity Score</p><p class="text-2xl font-bold text-white">{{ report.averageProductivityScore | number:'1.1-2' }}</p></div>
                    </div>
                    <section>
                        <h3 class="text-xl font-semibold text-gray-200 mb-4">Developer Productivity Scores</h3>
                        <div class="bg-gray-800 p-6 rounded-lg">
                            <app-bar-chart [data]="developerProductivityChartData()"></app-bar-chart>
                        </div>
                    </section>
                } @else {
                    <p class="text-gray-400">No report available for your team.</p>
                }
              </div>
            }
            @case ('DEVELOPER') {
              <div class="space-y-6">
                <h2 class="text-2xl font-semibold text-gray-200">Your Productivity Trend</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div class="bg-gray-800 p-4 rounded-lg"><p class="text-sm text-gray-400">Total Commits (last 30d)</p><p class="text-2xl font-bold text-white">{{ developerStats().totalCommits }}</p></div>
                  <div class="bg-gray-800 p-4 rounded-lg"><p class="text-sm text-gray-400">Total Tasks (last 30d)</p><p class="text-2xl font-bold text-white">{{ developerStats().totalTasks }}</p></div>
                  <div class="bg-gray-800 p-4 rounded-lg"><p class="text-sm text-gray-400">Avg Cycle Time (last 30d)</p><p class="text-2xl font-bold text-white">{{ developerStats().avgCycleTime | number:'1.1-1' }}h</p></div>
                </div>
                <div class="bg-gray-800 p-6 rounded-lg">
                    <h3 class="font-semibold text-lg text-gray-300 mb-4">Commits per Day</h3>
                    <app-line-chart [data]="developerCommitsChartData()"></app-line-chart>
                </div>
              </div>
            }
          }
        }
      </main>
    </div>

    @if (isAiAnalystOpen()) {
      <app-ai-analyst [reports]="ceoReports()" (close)="closeAiAnalyst()"></app-ai-analyst>
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DashboardComponent implements OnInit {
  private apiService = inject(ApiService);
  authService = inject(AuthService);

  loading = signal(true);
  error = signal<string | null>(null);
  isSyncing = signal(false);

  currentUser = this.authService.currentUser;
  
  ceoReports = signal<CeoReport[]>([]);
  developerProductivity = signal<DailyProductivity[]>([]);

  isAiAnalystOpen = signal(false);

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading.set(true);
    this.error.set(null);
    const user = this.currentUser();

    if (!user) {
      this.error.set("User not found.");
      this.loading.set(false);
      return;
    }

    switch (user.role) {
      case 'CEO':
        this.apiService.getReports().subscribe(this.dataHandler(this.ceoReports));
        break;
      case 'MANAGER':
        if (user.team?.id) {
          this.apiService.getReportsByTeam(user.team.id).subscribe(this.dataHandler(this.ceoReports));
        } else {
            this.error.set('You are not assigned to a team.');
            this.loading.set(false);
        }
        break;
      case 'DEVELOPER':
        this.apiService.getDeveloperProductivity(user.id).subscribe(this.dataHandler(this.developerProductivity));
        break;
    }
  }

  private dataHandler<T>(dataSignal: any) {
    return {
      next: (data: T) => {
        dataSignal.set(data);
        this.loading.set(false);
      },
      error: (err: any) => {
        console.error('Failed to load dashboard data', err);
        this.error.set('Could not load dashboard data. Please try again later.');
        this.loading.set(false);
      },
    };
  }

  syncData(): void {
    this.isSyncing.set(true);
    this.apiService.triggerDataSync().subscribe({
      next: () => {
        this.isSyncing.set(false);
        this.loadData();
      },
      error: (err) => {
        console.error('Data sync failed', err);
        this.error.set('Data synchronization failed.');
        this.isSyncing.set(false);
      }
    });
  }

  openAiAnalyst(): void {
    this.isAiAnalystOpen.set(true);
  }

  closeAiAnalyst(): void {
    this.isAiAnalystOpen.set(false);
  }

  teamProductivityChartData = computed(() => {
    return this.ceoReports().map(report => ({
      name: report.teamName ?? 'Unnamed Team',
      value: report.averageProductivityScore,
    }));
  });

  managerReport = computed(() => {
    return this.ceoReports()[0] ?? null;
  });

  developerProductivityChartData = computed(() => {
    const report = this.managerReport();
    if (!report) return [];
    return report.developerReports.map(dev => ({
      name: dev.developerName,
      value: dev.productivityScore,
    }));
  });

  developerStats = computed(() => {
    const productivity = this.developerProductivity();
    if (!productivity || productivity.length === 0) {
      return { totalCommits: 0, totalTasks: 0, avgCycleTime: 0 };
    }
    return {
      totalCommits: productivity.reduce((sum, day) => sum + day.commits, 0),
      totalTasks: productivity.reduce((sum, day) => sum + day.tasksCompleted, 0),
      avgCycleTime: productivity.reduce((sum, day) => sum + day.cycleTime, 0) / productivity.length,
    };
  });
  
  developerCommitsChartData = computed(() => {
    return this.developerProductivity()
      .slice(-15)
      .map(day => ({
        name: new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        value: day.commits
      }));
  });
}