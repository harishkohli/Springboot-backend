import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <div class="max-w-md w-full bg-gray-800 rounded-lg shadow-lg p-8">
        <h2 class="text-3xl font-bold text-center text-indigo-400 mb-6">Create Qugates Account</h2>
        <form (ngSubmit)="register()">
          @if (errorMessage()) {
            <div class="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-md mb-4" role="alert">
              {{ errorMessage() }}
            </div>
          }
          <div class="mb-4">
            <label for="name" class="block text-sm font-medium text-gray-300 mb-2">Full Name</label>
            <input
              type="text"
              id="name"
              name="name"
              class="w-full bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Your Name"
              [ngModel]="name()"
              (ngModelChange)="name.set($event)"
              required
            />
          </div>
          <div class="mb-4">
            <label for="email" class="block text-sm font-medium text-gray-300 mb-2">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              class="w-full bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="you@company.com"
              [ngModel]="email()"
              (ngModelChange)="email.set($event)"
              required
            />
          </div>
          <div class="mb-6">
            <label for="password" class="block text-sm font-medium text-gray-300 mb-2">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              class="w-full bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="••••••••"
              [ngModel]="password()"
              (ngModelChange)="password.set($event)"
              required
            />
          </div>
          <button
            type="submit"
            [disabled]="loading()"
            class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 transition-colors disabled:bg-indigo-900/50 disabled:cursor-not-allowed"
          >
            @if(loading()) {
              <span>Creating Account...</span>
            } @else {
              <span>Sign Up</span>
            }
          </button>
        </form>
        <p class="text-center text-gray-400 mt-6">
          Already have an account?
          <a routerLink="/login" class="text-indigo-400 hover:underline">Log in</a>
        </p>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RegisterComponent {
  authService = inject(AuthService);
  // FIX: Explicitly cast router to Router to fix type inference issue.
  router = inject(Router) as Router;

  // FIX: Use signals for form state management
  name = signal('');
  email = signal('');
  password = signal('');
  
  loading = signal(false);
  errorMessage = signal<string | null>(null);

  register(): void {
    this.loading.set(true);
    this.errorMessage.set(null);
    
    // Defaulting role to 'DEVELOPER' for new sign-ups. Admin/CEO would manage roles.
    const userData = {
      // FIX: Use signal values
      name: this.name(),
      email: this.email(),
      password: this.password(),
      role: 'DEVELOPER' as const
    };
    
    this.authService.register(userData).subscribe({
      next: () => {
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        this.errorMessage.set('Registration failed. The email might already be in use.');
        this.loading.set(false);
        console.error(err);
      },
      complete: () => {
        this.loading.set(false);
      }
    });
  }
}
