import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <div class="max-w-md w-full bg-gray-800 rounded-lg shadow-lg p-8">
        <h2 class="text-3xl font-bold text-center text-indigo-400 mb-6">Qugates Login</h2>
        <form (ngSubmit)="login()">
          @if (errorMessage()) {
            <div class="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-md mb-4" role="alert">
              {{ errorMessage() }}
            </div>
          }
          <div class="mb-4">
            <label for="email" class="block text-sm font-medium text-gray-300 mb-2">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              class="w-full bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="you@company.com"
              [ngModel]="email()"
              (ngModelChange)="email.set($event)"
              required
            />
          </div>
          <div class="mb-6">
            <label for="password" class="block text-sm font-medium text-gray-300 mb-2">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              class="w-full bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="••••••••"
              [ngModel]="password()"
              (ngModelChange)="password.set($event)"
              required
            />
          </div>
          <button
            type="submit"
            [disabled]="loading()"
            class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 transition-colors disabled:bg-indigo-900/50 disabled:cursor-not-allowed"
          >
            @if(loading()) {
              <span>Logging in...</span>
            } @else {
              <span>Login</span>
            }
          </button>
        </form>
        <p class="text-center text-gray-400 mt-6">
          Don't have an account?
          <a routerLink="/register" class="text-indigo-400 hover:underline">Sign up</a>
        </p>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  authService = inject(AuthService);
  // FIX: Explicitly cast router to Router to fix type inference issue.
  router = inject(Router) as Router;

  email = signal('');
  password = signal('');
  loading = signal(false);
  errorMessage = signal<string | null>(null);

  login(): void {
    this.loading.set(true);
    this.errorMessage.set(null);
    this.authService.login(this.email(), this.password()).subscribe({
      next: () => {
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        this.errorMessage.set('Login failed. Please check your credentials and try again.');
        this.loading.set(false);
        console.error(err);
      },
      complete: () => {
        this.loading.set(false);
      }
    });
  }
}
