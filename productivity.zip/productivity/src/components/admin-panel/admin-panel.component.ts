import { Component, ChangeDetectionStrategy, inject, signal, OnInit, computed } from '@angular/core';
import { CommonModule, TitleCasePipe, DecimalPipe, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { User, Team, DevExSurveySubmission } from '../../models';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-admin-panel',
  standalone: true,
  imports: [CommonModule, FormsModule, TitleCasePipe, DecimalPipe, DatePipe],
  template: `
    <div class="space-y-8">
      <header>
        <h1 class="text-3xl font-bold text-white">Admin Panel</h1>
        <p class="text-lg text-gray-400">Manage users, teams, and view developer experience insights.</p>
      </header>

      @if (loading()) {
        <div class="flex justify-center items-center p-8">
            <svg class="animate-spin h-10 w-10 text-indigo-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
        </div>
      } @else if (error()) {
        <div class="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded relative" role="alert">
          <span class="block sm:inline">{{ error() }}</span>
        </div>
      } @else {
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <!-- Manage Users -->
          <section class="bg-gray-800 p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-semibold text-gray-200 mb-4">Manage Users</h2>
            <div class="overflow-x-auto">
              <table class="w-full text-left">
                <thead>
                  <tr class="border-b border-gray-700">
                    <th class="p-3 text-sm font-semibold text-gray-400">Name</th>
                    <th class="p-3 text-sm font-semibold text-gray-400">Role</th>
                    <th class="p-3 text-sm font-semibold text-gray-400">Team</th>
                    <th class="p-3 text-sm font-semibold text-gray-400 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  @for (user of users(); track user.id) {
                    <tr class="border-b border-gray-700 last:border-0 hover:bg-gray-700/50">
                      <td class="p-3">
                        <p class="font-medium text-white">{{ user.name }}</p>
                        <p class="text-sm text-gray-400">{{ user.email }}</p>
                      </td>
                      <td class="p-3">{{ user.role | titlecase }}</td>
                      <td class="p-3">{{ user.team?.name || 'N/A' }}</td>
                      <td class="p-3 text-right">
                        <button (click)="openEditUserModal(user)" class="px-3 py-1 text-sm bg-indigo-600 hover:bg-indigo-700 rounded-md">Edit</button>
                      </td>
                    </tr>
                  } @empty {
                    <tr>
                        <td colspan="4" class="p-3 text-center text-gray-400">No users found.</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </section>

          <!-- Manage Teams -->
          <section class="bg-gray-800 p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-semibold text-gray-200 mb-4">Manage Teams</h2>
            <form (ngSubmit)="createTeam()" class="flex gap-2 mb-4">
              <input type="text"
                     placeholder="New team name"
                     class="flex-grow bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200 focus:ring-2 focus:ring-indigo-500"
                     [(ngModel)]="newTeamName"
                     name="newTeamName"
                     required />
              <button type="submit" [disabled]="!newTeamName.trim()"
                      class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-md disabled:bg-indigo-900/50 disabled:cursor-not-allowed">
                Create
              </button>
            </form>
            <ul class="space-y-2">
              @for (team of teams(); track team.id) {
                <li class="flex items-center justify-between p-3 bg-gray-900/50 rounded-md">
                  <div>
                    <span class="text-white">{{ team.name }}</span>
                    <span class="text-xs text-gray-400 ml-2">({{ teamMemberCounts().get(team.id) || 0 }} members)</span>
                  </div>
                  <div class="flex items-center gap-2">
                    <button (click)="openManageTeamModal(team)" class="px-3 py-1 text-sm bg-gray-600 hover:bg-gray-700 rounded-md">Manage</button>
                    <button (click)="deleteTeam(team)"
                            [disabled]="(teamMemberCounts().get(team.id) || 0) > 0"
                            [title]="(teamMemberCounts().get(team.id) || 0) > 0 ? 'Cannot delete team with assigned members' : 'Delete Team'"
                            class="text-red-400 hover:text-red-300 disabled:text-gray-600 disabled:cursor-not-allowed">
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clip-rule="evenodd" />
                      </svg>
                    </button>
                  </div>
                </li>
              } @empty {
                <li class="text-center text-gray-400 py-4">No teams found.</li>
              }
            </ul>
          </section>
        </div>

        <!-- DevEx Survey Insights -->
        <section class="bg-gray-800 p-6 rounded-lg shadow-lg mt-8">
          <h2 class="text-2xl font-semibold text-gray-200 mb-4">Developer Experience Insights</h2>
          @if (surveySubmissions().length > 0) {
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
              <!-- Quantitative Summary -->
              <div>
                <h3 class="text-lg font-semibold text-gray-300 mb-3">Average Ratings (out of 5)</h3>
                <ul class="space-y-4">
                  @for(result of aggregatedSurveyResults(); track result.questionId) {
                    <li class="space-y-1">
                      <div class="flex justify-between items-center text-sm text-gray-400">
                        <span>{{ result.questionText }}</span>
                        <span class="font-bold text-indigo-400">{{ result.averageRating | number:'1.1-2' }}</span>
                      </div>
                      <div class="w-full bg-gray-700 rounded-full h-2.5">
                        <div class="bg-indigo-600 h-2.5 rounded-full" [style.width.%]="(result.averageRating / 5) * 100"></div>
                      </div>
                    </li>
                  }
                </ul>
              </div>
              <!-- Qualitative Feedback -->
              <div>
                <h3 class="text-lg font-semibold text-gray-300 mb-3">Qualitative Feedback</h3>
                @if(surveyFeedback().length > 0) {
                  <div class="space-y-3 max-h-96 overflow-y-auto pr-2">
                    @for(fb of surveyFeedback(); track $index) {
                      <div class="bg-gray-900/50 p-3 rounded-md">
                        <p class="text-gray-300 text-sm italic">"{{ fb.feedback }}"</p>
                        <p class="text-right text-xs text-gray-500 mt-1">- {{ fb.developerName }} on {{ fb.date | date }}</p>
                      </div>
                    }
                  </div>
                } @else {
                  <p class="text-gray-500 text-center py-4">No written feedback submitted yet.</p>
                }
              </div>
            </div>
          } @else {
            <p class="text-center text-gray-400 py-4">No survey submissions found.</p>
          }
        </section>
      }
    </div>

    <!-- Edit User Modal -->
    @if (isEditUserModalOpen() && selectedUser(); as user) {
      <div class="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50" (click)="closeEditUserModal()">
        <div class="bg-gray-800 rounded-lg shadow-2xl w-full max-w-lg mx-4 p-6" (click)="$event.stopPropagation()">
          <h3 class="text-xl font-bold text-white mb-4">Edit User: {{ user.name }}</h3>
          <form (ngSubmit)="saveUserChanges()">
            <div class="space-y-4">
               <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label for="userRole" class="block text-sm font-medium text-gray-300 mb-2">Role</label>
                  <select id="userRole" name="role" class="w-full bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200" [(ngModel)]="editableUser.role">
                    <option value="DEVELOPER">Developer</option>
                    <option value="MANAGER">Manager</option>
                    <option value="CEO">CEO</option>
                  </select>
                </div>
                 <div>
                   <label for="userTeam" class="block text-sm font-medium text-gray-300 mb-2">Team</label>
                   <input id="userTeam" name="teamName" class="w-full bg-gray-700 border border-gray-600 rounded-md p-2 text-gray-400" [value]="user.team?.name || 'N/A'" readonly>
                   <p class="text-xs text-gray-400 mt-1">Use the "Manage" button in the teams list to change team assignments.</p>
                 </div>
              </div>
              <div>
                  <label for="githubUsername" class="block text-sm font-medium text-gray-300 mb-2">GitHub Username</label>
                  <input type="text" id="githubUsername" name="githubUsername" class="w-full bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200" placeholder="e.g., harishkohli" [(ngModel)]="editableUser.githubUsername" />
              </div>
            </div>
            <div class="mt-6 flex justify-end gap-3">
              <button type="button" (click)="closeEditUserModal()" class="px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded-md">Cancel</button>
              <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-md">Save Changes</button>
            </div>
          </form>
        </div>
      </div>
    }

    <!-- Manage Team Members Modal -->
    @if (isManageTeamModalOpen() && selectedTeamForManagement(); as team) {
      <div class="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50" (click)="closeManageTeamModal()">
        <div class="bg-gray-800 rounded-lg shadow-2xl w-full max-w-3xl mx-4 p-6" (click)="$event.stopPropagation()">
          <h3 class="text-xl font-bold text-white mb-4">Manage Members for: {{ team.name }}</h3>
          <div class="grid grid-cols-2 gap-6 h-96">
            <!-- Team Members -->
            <div class="flex flex-col">
              <h4 class="font-semibold mb-2">Team Members ({{ teamMembers().length }})</h4>
              <ul class="flex-grow bg-gray-900 border border-gray-700 rounded-md p-2 space-y-2 overflow-y-auto">
                @for(user of teamMembers(); track user.id) {
                  <li class="flex items-center justify-between bg-gray-800 p-2 rounded">
                    <span>{{ user.name }}</span>
                    <button (click)="unassignDeveloper(user)" class="p-1 text-red-400 hover:text-red-300" title="Remove from team">
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 000 2h6a1 1 0 100-2H7z" clip-rule="evenodd" /></svg>
                    </button>
                  </li>
                } @empty { <li class="text-center text-gray-500 p-4">No members</li> }
              </ul>
            </div>
            <!-- Available Developers -->
            <div class="flex flex-col">
              <h4 class="font-semibold mb-2">Available Developers ({{ availableDevelopers().length }})</h4>
              <ul class="flex-grow bg-gray-900 border border-gray-700 rounded-md p-2 space-y-2 overflow-y-auto">
                @for(user of availableDevelopers(); track user.id) {
                  <li class="flex items-center justify-between bg-gray-800 p-2 rounded">
                    <span>{{ user.name }}</span>
                    <button (click)="assignDeveloper(user)" class="p-1 text-green-400 hover:text-green-300" title="Add to team">
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clip-rule="evenodd" /></svg>
                    </button>
                  </li>
                } @empty { <li class="text-center text-gray-500 p-4">No available developers</li> }
              </ul>
            </div>
          </div>
          <div class="mt-6 flex justify-end gap-3">
              <button type="button" (click)="closeManageTeamModal()" class="px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded-md">Cancel</button>
              <button type="submit" (click)="saveTeamMembers()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-md">Save Members</button>
            </div>
        </div>
      </div>
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminPanelComponent implements OnInit {
  private apiService = inject(ApiService);

  loading = signal(true);
  error = signal<string | null>(null);

  users = signal<User[]>([]);
  teams = signal<Team[]>([]);
  surveySubmissions = signal<DevExSurveySubmission[]>([]);
  
  newTeamName: string = '';

  // State for Edit User Modal
  isEditUserModalOpen = signal(false);
  selectedUser = signal<User | null>(null);
  editableUser: { role: 'CEO' | 'MANAGER' | 'DEVELOPER', githubUsername: string } = { role: 'DEVELOPER', githubUsername: '' };
  
  // State for Manage Team Members Modal
  isManageTeamModalOpen = signal(false);
  selectedTeamForManagement = signal<Team | null>(null);
  teamMembers = signal<User[]>([]);
  availableDevelopers = signal<User[]>([]);
  
  teamMemberCounts = computed(() => {
    const counts = new Map<number, number>();
    this.users().forEach(user => {
      if (user.team?.id) {
        counts.set(user.team.id, (counts.get(user.team.id) || 0) + 1);
      }
    });
    return counts;
  });

  private questionMap = new Map<string, string>([
    ['tooling', 'Our development tools and environment are efficient.'],
    ['process', 'Our engineering processes (code reviews, testing) are effective.'],
    ['collaboration', 'I feel well-supported by my team and manager.'],
    ['impact', 'I have a clear understanding of how my work contributes to business goals.'],
    ['work_life', 'I am able to maintain a healthy work-life balance.']
  ]);

  aggregatedSurveyResults = computed(() => {
    const submissions = this.surveySubmissions();
    if (submissions.length === 0) return [];
    
    const results = new Map<string, { totalRating: number, count: number }>();
    for (const submission of submissions) {
      for (const response of submission.responses) {
        const current = results.get(response.questionId) || { totalRating: 0, count: 0 };
        current.totalRating += response.rating;
        current.count++;
        results.set(response.questionId, current);
      }
    }

    return Array.from(results.entries()).map(([questionId, data]) => ({
      questionId,
      questionText: this.questionMap.get(questionId) || 'Unknown Question',
      averageRating: data.count > 0 ? data.totalRating / data.count : 0,
    }));
  });

  surveyFeedback = computed(() => {
    return this.surveySubmissions()
      .filter(s => s.feedback && s.feedback.trim() !== '')
      .map(s => ({
        developerName: s.developerName || 'Anonymous',
        date: s.submissionDate,
        feedback: s.feedback
      }))
      .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading.set(true);
    this.error.set(null);
    forkJoin({
      users: this.apiService.getUsers().pipe(catchError(() => of([] as User[]))),
      teams: this.apiService.getTeams().pipe(catchError(() => of([] as Team[]))),
      surveySubmissions: this.apiService.getSurveyResults().pipe(catchError(() => of([] as DevExSurveySubmission[])))
    }).subscribe({
      next: ({ users, teams, surveySubmissions }) => {
        this.users.set(users);
        this.teams.set(teams);
        this.surveySubmissions.set(surveySubmissions);
      },
      error: (err) => {
        console.error('Failed to load admin data', err);
        this.error.set('Could not load data. Please try again later.');
      },
      complete: () => {
        this.loading.set(false);
      }
    });
  }

  createTeam(): void {
    const name = this.newTeamName.trim();
    if (!name) return;
    this.apiService.createTeam({ name }).subscribe({
      next: (newTeam) => { 
        this.teams.update(current => [...current, newTeam]);
        this.newTeamName = ''; 
      },
      error: (err) => console.error('Failed to create team', err),
    });
  }

  deleteTeam(team: Team): void {
    if (confirm(`Are you sure you want to delete the team "${team.name}"?`)) {
      this.apiService.deleteTeam(team.id).subscribe({
        next: () => this.loadData(),
        error: (err) => console.error('Failed to delete team', err),
      });
    }
  }
  
  openEditUserModal(user: User): void {
    this.selectedUser.set(JSON.parse(JSON.stringify(user)));
    this.editableUser = {
      role: user.role,
      githubUsername: user.githubUsername || ''
    };
    this.isEditUserModalOpen.set(true);
  }

  closeEditUserModal(): void {
    this.isEditUserModalOpen.set(false);
    this.selectedUser.set(null);
  }
  
  saveUserChanges(): void {
    const userToUpdate = this.selectedUser();
    if (!userToUpdate) return;
    
    const payload: User = {
        ...userToUpdate,
        role: this.editableUser.role,
        githubUsername: this.editableUser.githubUsername
    };

    this.apiService.updateUser(payload).subscribe({
      next: (updatedUser) => { 
        this.users.update(users => users.map(u => u.id === updatedUser.id ? updatedUser : u));
        this.closeEditUserModal(); 
      },
      error: (err) => console.error('Failed to update user', err),
    });
  }

  // --- Manage Team Members Logic ---
  openManageTeamModal(team: Team): void {
    this.selectedTeamForManagement.set(team);
    const allUsers = this.users();
    const members = allUsers.filter(u => u.team?.id === team.id);
    const available = allUsers.filter(u => !u.team && u.role === 'DEVELOPER');
    
    this.teamMembers.set(members);
    this.availableDevelopers.set(available);
    this.isManageTeamModalOpen.set(true);
  }

  closeManageTeamModal(): void {
    this.isManageTeamModalOpen.set(false);
    this.selectedTeamForManagement.set(null);
    this.teamMembers.set([]);
    this.availableDevelopers.set([]);
  }

  assignDeveloper(user: User): void {
    this.availableDevelopers.update(users => users.filter(u => u.id !== user.id));
    this.teamMembers.update(users => [...users, user].sort((a,b) => a.name.localeCompare(b.name)));
  }

  unassignDeveloper(user: User): void {
    this.teamMembers.update(users => users.filter(u => u.id !== user.id));
    this.availableDevelopers.update(users => [...users, user].sort((a,b) => a.name.localeCompare(b.name)));
  }

  saveTeamMembers(): void {
    const team = this.selectedTeamForManagement();
    if (!team) return;
    const memberIds = this.teamMembers().map(u => u.id);
    
    this.apiService.updateTeamMembers(team.id, memberIds).subscribe({
      next: () => {
        this.closeManageTeamModal();
        this.loadData(); // Reload all data to ensure consistency
      },
      error: (err) => {
        console.error('Failed to update team members', err);
        alert('Could not update team members. Please try again.');
      }
    });
  }
}
