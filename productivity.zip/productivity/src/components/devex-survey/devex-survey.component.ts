import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { DevExSurveyRating } from '../../models';

interface SurveyQuestion {
  id: string;
  text: string;
  description: string;
}

@Component({
  selector: 'app-devex-survey',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="max-w-4xl mx-auto">
      <header class="mb-8">
        <h1 class="text-3xl font-bold text-white">Developer Experience Survey</h1>
        <p class="text-lg text-gray-400 mt-2">Your feedback is anonymous and helps us improve our engineering culture and processes.</p>
      </header>

      @if (success()) {
        <div class="bg-green-900/50 border border-green-700 text-green-300 px-6 py-8 rounded-lg text-center">
          <h2 class="text-2xl font-semibold mb-2">Thank You!</h2>
          <p>Your survey has been submitted successfully.</p>
        </div>
      } @else {
        <form (ngSubmit)="submitSurvey()" class="bg-gray-800 p-8 rounded-lg space-y-8">
          <div class="space-y-6">
            @for(question of surveyQuestions; track question.id) {
              <div>
                <label class="block text-lg font-semibold text-gray-200">{{ question.text }}</label>
                <p class="text-sm text-gray-400 mb-3">{{ question.description }}</p>
                <div class="flex items-center justify-center space-x-2 bg-gray-900/50 p-3 rounded-md">
                  <span class="text-gray-400">Strongly Disagree</span>
                  @for(rating of [1, 2, 3, 4, 5]; track rating) {
                    <label 
                      [for]="question.id + '-' + rating"
                      class="relative flex items-center justify-center w-10 h-10 rounded-full cursor-pointer transition-colors"
                      [class.bg-indigo-600]="responses()[question.id] === rating"
                      [class.hover:bg-gray-700]="responses()[question.id] !== rating"
                      [class.text-white]="responses()[question.id] === rating"
                      [class.text-gray-300]="responses()[question.id] !== rating"
                    >
                      {{ rating }}
                      <input 
                        type="radio" 
                        [id]="question.id + '-' + rating" 
                        [name]="question.id" 
                        [value]="rating" 
                        (change)="setRating(question.id, rating)"
                        class="absolute opacity-0 w-0 h-0"
                      >
                    </label>
                  }
                  <span class="text-gray-400">Strongly Agree</span>
                </div>
              </div>
            }
          </div>

          <div>
            <label for="feedback" class="block text-lg font-semibold text-gray-200">
              Is there anything else you'd like to share?
            </label>
            <p class="text-sm text-gray-400 mb-3">
              What could we do to improve your experience? Any specific pain points or suggestions?
            </p>
            <textarea 
              id="feedback" 
              name="feedback" 
              rows="4"
              class="w-full bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200 focus:ring-2 focus:ring-indigo-500"
              placeholder="Your feedback is valuable..."
              [ngModel]="feedback()"
              (ngModelChange)="feedback.set($event)"
            ></textarea>
          </div>

          @if (error()) {
            <div class="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-md" role="alert">
              {{ error() }}
            </div>
          }

          <div class="flex justify-end">
            <button 
              type="submit" 
              [disabled]="submitting() || !isFormValid()"
              class="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 transition-colors disabled:bg-indigo-900/50 disabled:cursor-not-allowed flex items-center"
            >
              @if(submitting()) {
                <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Submitting...</span>
              } @else {
                <span>Submit Survey</span>
              }
            </button>
          </div>
        </form>
      }
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DevexSurveyComponent {
  private apiService = inject(ApiService);

  surveyQuestions: SurveyQuestion[] = [
    {
      id: 'tooling',
      text: 'Our development tools and environment are efficient.',
      description: 'Consider your IDE, build tools, CI/CD pipeline, and local setup.'
    },
    {
      id: 'process',
      text: 'Our engineering processes (code reviews, testing) are effective and not overly bureaucratic.',
      description: 'Think about the speed and quality of feedback you get on your work.'
    },
    {
      id: 'collaboration',
      text: 'I feel well-supported by my team and manager.',
      description: 'Collaboration is smooth, and I can easily get help when I need it.'
    },
    {
      id: 'impact',
      text: 'I have a clear understanding of how my work contributes to business goals.',
      description: 'I feel that the work I do is meaningful and impactful.'
    },
    {
      id: 'work_life',
      text: 'I am able to maintain a healthy work-life balance.',
      description: 'Consider on-call rotations, overtime expectations, and flexibility.'
    }
  ];

  responses = signal<{ [questionId: string]: number }>({});
  feedback = signal('');
  submitting = signal(false);
  error = signal<string | null>(null);
  success = signal(false);
  
  isFormValid(): boolean {
      return this.surveyQuestions.every(q => this.responses()[q.id] !== undefined);
  }

  setRating(questionId: string, rating: number): void {
    this.responses.update(current => ({ ...current, [questionId]: rating }));
  }

  submitSurvey(): void {
    if (!this.isFormValid()) {
      this.error.set("Please answer all rating questions.");
      return;
    }
    this.submitting.set(true);
    this.error.set(null);

    const surveyResponses: DevExSurveyRating[] = Object.entries(this.responses()).map(([questionId, rating]) => ({
      questionId,
      rating
    }));
    
    const surveyData = {
      feedback: this.feedback(),
      // FIX: The backend DTO expects this field to be named 'ratings', not 'responses'.
      ratings: surveyResponses,
    };

    this.apiService.submitSurvey(surveyData).subscribe({
      next: () => {
        this.success.set(true);
        this.submitting.set(false);
      },
      error: (err) => {
        console.error('Survey submission failed', err);
        this.error.set('Failed to submit the survey. Please try again later.');
        this.submitting.set(false);
      }
    });
  }
}