import { Component, ChangeDetectionStrategy, input, output, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CeoReport } from '../../models';
import { AiAnalyzerService } from '../../services/ai-analyzer.service';

@Component({
  selector: 'app-ai-analyst',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50" (click)="closeModal()">
      <div class="bg-gray-800 rounded-lg shadow-2xl w-full max-w-2xl mx-4 transform transition-all" (click)="$event.stopPropagation()">
        <header class="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 class="text-xl font-bold flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
            AI Productivity Analyst
          </h2>
          <button (click)="closeModal()" class="text-gray-400 hover:text-white transition-colors">
             <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
               <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
             </svg>
          </button>
        </header>

        <main class="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          <div>
            <label for="ai-query" class="block text-sm font-medium text-gray-300 mb-2">Ask a question about the team's productivity:</label>
            <textarea id="ai-query" name="ai-query" rows="3"
                class="w-full bg-gray-900 border border-gray-700 rounded-md p-2 text-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="e.g., 'Which team has the highest productivity score?' or 'Summarize performance of the Phoenix team.'"
                [ngModel]="userQuery()"
                (ngModelChange)="userQuery.set($event)"
            ></textarea>
          </div>

           <div class="flex items-center space-x-2">
                <button (click)="generateInsights()" [disabled]="loading() || !userQuery()"
                    class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-md disabled:bg-indigo-900/50 disabled:cursor-not-allowed flex items-center justify-center">
                    @if(loading()) {
                        <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span>Generating...</span>
                    } @else {
                        <span>Generate Insights</span>
                    }
                </button>
                <button (click)="selectExample('Analyze our teams based on DORA metrics. Which team is most efficient?')" class="text-xs text-gray-400 hover:text-indigo-300 p-1">Example</button>
            </div>


          @if (error()) {
            <div class="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded relative" role="alert">
              <span class="block sm:inline">{{ error() }}</span>
            </div>
          }

          @if (aiResponse()) {
            <div class="mt-4 bg-gray-900/50 p-4 rounded-lg border border-gray-700">
              <h3 class="text-lg font-semibold text-indigo-400 mb-2">AI Analysis:</h3>
              <div class="prose prose-invert max-w-none" [innerHTML]="formattedResponse()"></div>
            </div>
          }
        </main>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    .prose {
      color: #d1d5db; /* gray-300 */
    }
    .prose h1, .prose h2, .prose h3, .prose h4 {
      color: #e5e7eb; /* gray-200 */
    }
    .prose strong {
      color: #f9fafb; /* gray-50 */
    }
    .prose ul > li {
        margin-top: 0.5em;
        margin-bottom: 0.5em;
    }
  `]
})
export class AiAnalystComponent {
  reports = input.required<CeoReport[]>();
  close = output<void>();

  aiAnalyzerService = inject(AiAnalyzerService);

  userQuery = signal("Summarize the productivity reports. Which team is performing the best and who might need support?");
  aiResponse = signal('');
  loading = signal(false);
  error = signal<string | null>(null);

  formattedResponse = computed(() => {
    // Basic markdown to HTML conversion.
    // In a real app, a library like 'marked' would be better and safer.
    const text = this.aiResponse();
    if (!text) return '';
    
    let html = text
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/^### (.*$)/gim, '<h3>$1</h3>')
      .replace(/^## (.*$)/gim, '<h2>$1</h2>')
      .replace(/^# (.*$)/gim, '<h1>$1</h1>')
      .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/gim, '<em>$1</em>')
      .replace(/^\s*\n\*/gm, '<ul>\n*')
      .replace(/^(\*.+)\s*\n([^*])/gm, '$1\n</ul>\n$2')
      .replace(/^\* (.*$)/gim, '<li>$1</li>')
      .replace(/\n/gim, '<br />')
      .replace(/<\/li><br \/>/g, '</li>')
      .replace(/<\/ul><br \/>/g, '</ul>')
      .replace(/<br \/><ul>/g, '<ul>')
      .replace(/<br \/><li>/g, '<li>');
      
    if (html.includes('<li>') && !html.endsWith('</ul>')) {
        html += '</ul>';
    }

    return html;
  });
  
  closeModal(): void {
    this.close.emit();
  }
  
  selectExample(prompt: string): void {
    this.userQuery.set(prompt);
  }

  async generateInsights(): Promise<void> {
    if (!this.userQuery()) return;

    this.loading.set(true);
    this.error.set(null);
    this.aiResponse.set('');

    try {
      const response = await this.aiAnalyzerService.getProductivityInsights(this.userQuery(), this.reports());
      this.aiResponse.set(response);
    } catch (err: unknown) {
      if (err instanceof Error) {
        this.error.set(err.message);
      } else {
        this.error.set('An unknown error occurred.');
      }
    } finally {
      this.loading.set(false);
    }
  }
}