import { Component, ChangeDetectionStrategy, input, ElementRef, AfterViewInit, ViewChild, OnChanges, SimpleChanges } from '@angular/core';

declare const d3: any;

@Component({
  selector: 'app-line-chart',
  template: `<div #chart class="w-full h-96"></div>`,
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LineChartComponent implements AfterViewInit, OnChanges {
  data = input.required<{ name: string; value: number }[]>();

  @ViewChild('chart') private chartContainer!: ElementRef;

  ngAfterViewInit(): void {
    if (this.data().length > 0) {
      this.createChart();
    }
  }
  
  ngOnChanges(changes: SimpleChanges): void {
      if (changes['data'] && this.chartContainer) {
          this.createChart();
      }
  }

  private createChart(): void {
    const element = this.chartContainer.nativeElement;
    d3.select(element).select('svg').remove();

    const data = this.data();
    if (data.length === 0) return;

    const margin = { top: 20, right: 20, bottom: 70, left: 40 };
    const width = element.offsetWidth - margin.left - margin.right;
    const height = element.offsetHeight - margin.top - margin.bottom;

    const svg = d3.select(element).append('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const x = d3.scaleBand()
      .range([0, width])
      .domain(data.map(d => d.name))
      .padding(0.1);

    svg.append('g')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(x))
      .selectAll('text')
      .attr('transform', 'translate(-10,0)rotate(-45)')
      .style('text-anchor', 'end')
      .style('fill', '#9ca3af');

    const y = d3.scaleLinear()
      .domain([0, d3.max(data, (d:any) => d.value) * 1.2 || 10])
      .range([height, 0]);

    svg.append('g')
      .call(d3.axisLeft(y))
      .selectAll('text')
      .style('fill', '#9ca3af');
      
    // Add the line
    svg.append("path")
      .datum(data)
      .attr("fill", "none")
      .attr("stroke", "#4f46e5")
      .attr("stroke-width", 2.5)
      .attr("d", d3.line()
        .x((d:any) => x(d.name) + x.bandwidth()/2)
        .y((d:any) => y(d.value))
      );

    // Add the points
    svg.selectAll("myCircles")
      .data(data)
      .enter()
      .append("circle")
        .attr("fill", "#818cf8")
        .attr("stroke", "none")
        .attr("cx", (d:any) => x(d.name) + x.bandwidth()/2)
        .attr("cy", (d:any) => y(d.value))
        .attr("r", 4);
  }
}