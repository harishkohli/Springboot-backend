export const environment = {
  apiBaseUrl: 'http://localhost:8080',
};