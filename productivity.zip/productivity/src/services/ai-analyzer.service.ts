import { Injectable } from '@angular/core';
import { CeoReport } from '../models';

@Injectable({
  providedIn: 'root',
})
export class AiAnalyzerService {

  constructor() {
    // No API key initialization is needed anymore.
  }

  /**
   * Simulates an AI analysis of the productivity reports.
   * This function works offline and does not require an API key.
   * @param userQuery The user's question (ignored in this simulation, but kept for API consistency).
   * @param reports The CEO reports to be analyzed.
   * @returns A promise that resolves with a markdown-formatted string of insights.
   */
  getProductivityInsights(
    userQuery: string,
    reports: CeoReport[]
  ): Promise<string> {
    // Simulate network latency for a more realistic user experience
    return new Promise(resolve => {
      setTimeout(() => {
        const analysis = this.generateMockAnalysis(reports);
        resolve(analysis);
      }, 1500); // 1.5 second delay
    });
  }

  private generateMockAnalysis(reports: CeoReport[]): string {
    if (!reports || reports.length === 0) {
      return "There is no data available to analyze. Please ensure data has been synced successfully.";
    }

    // Sort teams by productivity score to find the best and worst performers
    const sortedReports = [...reports].sort((a, b) => b.averageProductivityScore - a.averageProductivityScore);
    
    const topTeam = sortedReports[0];
    const bottomTeam = sortedReports[sortedReports.length - 1];

    let analysis = `
### Summary of Team Performance

Here is a brief analysis based on the latest productivity data:

**Top Performer: ${topTeam.teamName}**
*   **Productivity Score:** **${topTeam.averageProductivityScore.toFixed(2)}**
*   This team demonstrates exceptional efficiency, leading with the highest productivity score.
*   Their DORA metrics are strong, particularly their high deployment frequency (${topTeam.deploymentFrequency.toFixed(1)}/wk) and low lead time for changes (${topTeam.leadTimeForChanges.toFixed(1)}h), which indicates a very healthy and agile development process.

`;

    if (sortedReports.length > 1 && topTeam.teamId !== bottomTeam.teamId) {
      analysis += `
**Area for Focus: ${bottomTeam.teamName}**
*   **Productivity Score:** **${bottomTeam.averageProductivityScore.toFixed(2)}**
*   This team's productivity score is lower relative to others. 
*   It may be beneficial to investigate potential bottlenecks. Their lead time for changes (${bottomTeam.leadTimeForChanges.toFixed(1)}h) is higher, which could suggest opportunities to streamline their code review or testing pipelines.

`;
    }

    analysis += `
### Overall Recommendation
The data suggests a generally healthy organization. The key takeaway is to learn from the success of the **${topTeam.teamName}** team and see if their successful practices can be adapted to support the **${bottomTeam.teamName}** team.
    `;

    return analysis.trim();
  }
}
