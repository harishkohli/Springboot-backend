import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { User } from '../models';

interface AuthResponse {
  token: string;
  user: User;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private http = inject(HttpClient);
  // FIX: Explicitly cast router to Router to fix type inference issue.
  private router = inject(Router) as Router;

  private readonly TOKEN_KEY = 'devdash_token';
  private readonly USER_KEY = 'devdash_user';

  currentUser = signal<User | null>(null);
  jwtToken = signal<string | null>(null);

  constructor() {
    // on service initialization, try to load user from local storage
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem(this.TOKEN_KEY);
      const userJson = localStorage.getItem(this.USER_KEY);
      if (token && userJson) {
        this.jwtToken.set(token);
        this.currentUser.set(JSON.parse(userJson));
      }
    }
  }

  isLoggedIn(): boolean {
    return !!this.jwtToken();
  }
  
  login(email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${environment.apiBaseUrl}/api/auth/login`, { email, password })
      .pipe(
        tap(response => {
          this.handleAuthentication(response.token, response.user);
        }),
        catchError(err => {
            // clear state on failure
            this.logout(false); // Don't navigate on login failure
            throw err;
        })
      );
  }

  register(userData: Partial<User>): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${environment.apiBaseUrl}/api/auth/register`, userData)
      .pipe(
        tap(response => {
          this.handleAuthentication(response.token, response.user);
        })
      );
  }

  logout(navigate = true): void {
    this.currentUser.set(null);
    this.jwtToken.set(null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem(this.TOKEN_KEY);
      localStorage.removeItem(this.USER_KEY);
    }
    if (navigate) {
      this.router.navigate(['/login']);
    }
  }

  private handleAuthentication(token: string, user: User): void {
    this.jwtToken.set(token);
    this.currentUser.set(user);
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.TOKEN_KEY, token);
      localStorage.setItem(this.USER_KEY, JSON.stringify(user));
    }
  }
}
