import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../environments/environment';
import { CeoReport, DailyProductivity, User, Team, DevExSurveySubmission } from '../models';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiBaseUrl}/api`;

  // === Dashboard Endpoints ===

  getReports(): Observable<CeoReport[]> {
    return this.http.get<CeoReport[]>(`${this.baseUrl}/reports`);
  }

  getReportsByTeam(teamId: number): Observable<CeoReport[]> {
    return this.http.get<CeoReport[]>(`${this.baseUrl}/reports/team/${teamId}`);
  }

  getDeveloperProductivity(developerId: number): Observable<DailyProductivity[]> {
    return this.http.get<DailyProductivity[]>(`${this.baseUrl}/productivity/developer/${developerId}`);
  }

  triggerDataSync(): Observable<string> {
    return this.http.post<string>(`${this.baseUrl}/data/sync-now`, {});
  }

  // === Admin Panel Endpoints ===

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.baseUrl}/developers`);
  }

  getTeams(): Observable<Team[]> {
    return this.http.get<Team[]>(`${this.baseUrl}/teams`);
  }
  
  createTeam(team: { name: string }): Observable<Team> {
    return this.http.post<Team>(`${this.baseUrl}/teams`, team);
  }

  deleteTeam(teamId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/teams/${teamId}`);
  }

  updateUser(user: User): Observable<User> {
    if (!user || typeof user.id !== 'number') {
      return throwError(() => new Error('Cannot update user without a valid ID.'));
    }
    return this.http.put<User>(`${this.baseUrl}/developers/${user.id}`, user);
  }
  
  // **NEW METHOD to update team members**
  updateTeamMembers(teamId: number, developerIds: number[]): Observable<Team> {
    // The backend expects an object with a 'developerIds' key
    return this.http.put<Team>(`${this.baseUrl}/teams/${teamId}/members`, { developerIds });
  }

  // === DevEx Survey Endpoint ===

  submitSurvey(surveyData: any): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/devex/survey`, surveyData);
  }

  getSurveyResults(): Observable<DevExSurveySubmission[]> {
    return this.http.get<DevExSurveySubmission[]>(`${this.baseUrl}/devex/surveys`);
  }
}